# -*- coding: utf-8 -*-
"""
Created on Tue Feb  2 12:38:33 2021

@author: JARBY II
"""

from setuptools import setup

setup(
      name='paqueteCalculos',
      version='1.0',
      description='Paquete de redondeo y potencia',
      author='Fabian',
      author_email='fhr.88@gmail.com',
      url='www.fhr88.com',
      packages=['paquete_calculos','paquete_calculos.redondeo_potencia'],

      

      )