# -*- coding: utf-8 -*-
"""
Created on Mon Feb  1 16:29:02 2021

@author: JARBY II
"""

def potencia(base, exponente):
    print('El resultado de la potencia es: ', base**exponente)
    
def redondear(numero):
    print('El resultado del redondeo es: ', round(numero))